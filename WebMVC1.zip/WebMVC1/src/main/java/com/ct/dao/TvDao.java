package com.ct.dao;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ct.model.Tv;

public class TvDao {
	
	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	  
	public int saveTv(Tv t){  
	    String query="insert into tv(tvName, tvBrand, tvPrice, tvQuantity, tvDescription, tvDiscount) values(?,?,?,?,?,?)" ;
	    System.out.println(t.getTvName() + " " +  t.getTvBrand());
	    return jdbcTemplate.update(query, new Object[] {t.getTvName(), t.getTvBrand(), t.getTvPrice(), t.getTvQuantity(), t.getTvDescription(), t.getTvDiscount()} );  
	}
	
	
}
