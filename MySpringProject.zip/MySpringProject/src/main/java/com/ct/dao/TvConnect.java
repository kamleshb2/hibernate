package com.ct.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.ct.model.Tv;

@Component
public class TvConnect implements ITvConnect {

	
	static Session session = DbUtil.getSessionFactory().openSession();
	
	@Override
	public void addTv(Tv t) {
		
		session.save(t);
		session.beginTransaction();
		session.getTransaction().commit();
	}

	@Override
	public List<Tv> displayTv() {
	
	session.beginTransaction();
	Criteria criteria = session.createCriteria(Tv.class);
	List<Tv> tv = criteria.list();        
	/*String query ="select * from Tv t";
	SQLQuery qr = session.createSQLQuery(query);
	qr.addEntity(Tv.class);
	List<Tv> tv = qr.list();*/
	/*Query qr = session.createQuery(query);
	List<Tv> tv = qr.list();*/
	session.getTransaction().commit();
	session.close();
	return tv;
	
		
	}

	@Override
	public Tv retriveTv(int tId) {
		
		session.beginTransaction();
		Tv t = (Tv) session.get(Tv.class, tId);
		session.getTransaction().commit();
		session.close();
		return t;
		
	}

	

	
}
