package com.ct.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.metamodel.Metadata;
import org.hibernate.metamodel.MetadataSources;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.transform.Transformers;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory sf=new Configuration().configure().buildSessionFactory();
    	Session session = sf.openSession();
    	Prod_Description pd = new Prod_Description();
    
    	Criteria c=session.createCriteria(Prod_Description.class);  
    	Projection projection = Projections.property("prodId");    
    	Projection projection2 = Projections.property("name"); 
    	ProjectionList pList = Projections.projectionList(); 
    	pList.add(projection, "prodId"); 
    	pList.add(projection2, "name"); 
    	
    	c.setProjection(pList);
    	c.setResultTransformer(Transformers.aliasToBean(Prod_Description.class));
    	List list = c.list();
    	
    	System.out.println(list);
    	
    	
    	
    	
    	
    	
    }
}
